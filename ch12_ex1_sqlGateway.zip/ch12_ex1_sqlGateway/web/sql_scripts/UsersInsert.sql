INSERT INTO UserTest 
    (FirstName, LastName, EmailAddress)
VALUES 
    ('John', 'Smith', 'jsmith@gmail.com'), 
    ('Andrea', 'Steelman', 'andrea@murach.com'), 
    ('Joel', 'Murach', 'joelmurach@yahoo.com')
